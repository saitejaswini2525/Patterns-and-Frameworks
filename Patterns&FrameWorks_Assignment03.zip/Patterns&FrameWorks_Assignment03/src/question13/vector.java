package question13;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class vector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		        
		        
		        List<String> arrayList = new ArrayList<>();
		        arrayList.add("one");
		        arrayList.add("two");
		        arrayList.add("three");
		        System.out.println("ArrayList: " + arrayList);
		        
		        
		        Vector<String> vector = new Vector<>();
		        vector.add("one");
		        vector.add("two");
		        vector.add("three");
		        System.out.println("Vector: " + vector);
		    }
		


	}


