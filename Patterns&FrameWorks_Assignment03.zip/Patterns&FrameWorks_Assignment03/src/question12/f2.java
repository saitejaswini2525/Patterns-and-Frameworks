package question12;

public class f2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
