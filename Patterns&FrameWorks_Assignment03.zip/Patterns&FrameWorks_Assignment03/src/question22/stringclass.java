package question22;

public class stringclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		immutable person = new immutable("John Doe", 30);
        String name = person.getName();
        int age = person.getAge();
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
	}


