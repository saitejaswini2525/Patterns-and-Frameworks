package question22;

public class immutable {

	
		
		    private final String name;
		    private final int age;

		    public immutable(String name, int age) {
		        this.name = name;
		        this.age = age;
		    }

		    public String getName() {
		        return name;
		    }

		    public int getAge() {
		        return age;
		    }
		

	}


