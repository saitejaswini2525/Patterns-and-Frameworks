package question10;

public class throwex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
