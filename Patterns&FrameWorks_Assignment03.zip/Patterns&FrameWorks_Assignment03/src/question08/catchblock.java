package question08;

public class catchblock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
	         System.out.println("Apple");
	      } finally {
	         System.out.println("Strawberry");
	      }


	}

}
