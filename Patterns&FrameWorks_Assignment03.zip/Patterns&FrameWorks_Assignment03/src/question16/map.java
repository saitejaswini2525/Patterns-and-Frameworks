package question16;
import java.util.HashMap;
import java.util.Map;
public class map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	

		        Map<String, Integer> hashMap = new HashMap<>();
		        hashMap.put("one", 1);
		        hashMap.put("two", 2);
		        hashMap.put("three", 3);
		        System.out.println("HashMap: " + hashMap);
		        
		        
		        int value = hashMap.get("two");
		        System.out.println("Value of key 'two': " + value);
		        
		        
		        hashMap.remove("three");
		        System.out.println("HashMap after removing key 'three': " + hashMap);
		    
	}

}
