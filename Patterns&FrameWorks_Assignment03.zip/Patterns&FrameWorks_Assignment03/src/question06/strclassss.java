package question06;

public class strclassss {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer Buffer = new StringBuffer("sai yarapathineni");
	      Buffer.append(" String Buffer");
	      System.out.println(Buffer);
	   }

}
