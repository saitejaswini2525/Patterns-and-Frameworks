package question06;

public class str {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Sai tejaswini";
	      int ma = str.length();
	      System.out.println( "String Length is : " + ma );

	}

}
