package question07;

import question07.cons;

public class finalC {
	 constr obj = new constr();
}
