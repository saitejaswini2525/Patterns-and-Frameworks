package question07;

public class cons {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
