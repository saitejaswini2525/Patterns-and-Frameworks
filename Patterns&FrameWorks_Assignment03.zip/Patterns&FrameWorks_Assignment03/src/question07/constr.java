package question07;
import java.io.*;

public class constr {

	
		 constr(){
			    {
			        // This line can not be executed as compile error
			        // will come
			        System.out.print(
			            "Constructor error");
			    }

	}

}
