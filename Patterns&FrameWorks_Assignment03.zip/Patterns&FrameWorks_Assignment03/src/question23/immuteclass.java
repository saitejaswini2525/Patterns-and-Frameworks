package question23;

public class immuteclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		immute person = new immute("Sai", 16);
		new Thread(() -> {
            String name = person.getName();
            int age = person.getAge();
            System.out.println("Thread 1 - Name: " + name);
            System.out.println("Thread 1 - Age: " + age);
        }).start();

        
        new Thread(() -> {
            String name = person.getName();
            int age = person.getAge();
            System.out.println("Thread 2 - Name: " + name);
            System.out.println("Thread 2 - Age: " + age);
        }).start();
    }
	

}
