package question23;

public final class immute {

	
		
		    private final String name;
		    private final int age;

		    public immute(String name, int age) {
		        this.name = name;
		        this.age = age;
		    }

		    public String getName() {
		        return name;
		    }

		    public int getAge() {
		        return age;
		    }
		
	}


