package question03;
import java.util.*;
import question03.covariant;

public class covariant {
	covariant get() {
	      System.out.println("SuperClass");
	      return this;
	   }

}
