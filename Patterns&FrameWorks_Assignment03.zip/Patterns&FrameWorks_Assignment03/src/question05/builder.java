package question05;

public class builder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder strng= new StringBuilder("Hello");

    strng.append(" World!");

    System.out.println(strng);
}
	
	

}
