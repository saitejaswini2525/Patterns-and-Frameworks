package question05;

public class buffer {
	public static void main(String args[])
    {
  
        
        StringBuffer strng = new StringBuffer("Hello");
  
        strng.append(" World!");
  
        System.out.println(strng);
    }
}
