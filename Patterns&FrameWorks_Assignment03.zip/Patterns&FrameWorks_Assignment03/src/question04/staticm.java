package question04;

public class staticm {
	 void display() {
	      System.out.println("Super class");    
	   }

}
