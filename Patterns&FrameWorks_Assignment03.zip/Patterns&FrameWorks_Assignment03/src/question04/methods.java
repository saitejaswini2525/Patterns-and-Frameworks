package question04;


public class methods extends staticm {
	   protected void display() { // trying to override display() {
	      System.out.println("class");
	   }
	   public static void main(String[] args) {
	      staticm object1 = new methods();
	      object1.display();
	   }
	


}


