package question02;



public class override {
	class Superclass {
	    public void publicMethod() {
	        System.out.println("public method in the superclass");
	    }

	    protected void protectedMethod() {
	        System.out.println("protected method");
	    }

	    void defaultMethod() {
	        System.out.println("default method");
	    }
	}

	class Subclass extends Superclass {
	    
	    public void publicMethod() {
	        System.out.println("public method in subclass");
	    }

	    protected void protectedMethod() {
	        System.out.println("protected method in subclass");
	    }

	    void defaultMethod() {
	        System.out.println("default method in subclass");
	    }

	    
	}


}
