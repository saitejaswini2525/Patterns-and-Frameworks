package question01;

public class generics<T>{
	
	    private T item;

	    public void setItem(T item) {
	        this.item = item;
	    }

	    public T getItem() {
	        return this.item;
	    }
	}



