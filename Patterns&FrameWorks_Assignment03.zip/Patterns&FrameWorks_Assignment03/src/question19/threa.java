package question19;



public class threa implements Runnable {
	    public void run()
	    {
	        System.out.println("Sai Teja");
	        }

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			 Runnable run = (Runnable) new threa();
		        Thread th = new Thread(run, "My Thread");
		        // Thread object started
		        th.run();
		        // getting the Thread
		          // with String Method
		        String stgr = th.getName();
		        System.out.println(stgr);
		    }

	
}
