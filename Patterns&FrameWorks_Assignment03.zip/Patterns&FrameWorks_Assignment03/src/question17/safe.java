package question17;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class safe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String, Integer> map = new ConcurrentHashMap<>();
		map.put("one", 1);
		map.put("two", 2);
		map.put("three", 3);

		Iterator<Map.Entry<String, Integer>> it = map.entrySet().iterator();
		while (it.hasNext()) {
		    Map.Entry<String, Integer> entry = it.next();
		    System.out.println(entry.getKey() + " : " + entry.getValue());
		    map.put("four", 4); // No concurrent modification exception
	}

}
}