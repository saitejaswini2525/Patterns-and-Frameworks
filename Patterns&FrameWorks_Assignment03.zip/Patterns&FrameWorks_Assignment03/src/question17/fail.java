package question17;

import java.util.ArrayList;
import java.util.List;

import javax.swing.text.html.HTMLDocument.Iterator;

public class fail {

	
		List<Integer> list1 = new ArrayList<>();
		

		Iterator it = (Iterator) list1.iterator();{
		while (((java.util.Iterator<Integer>) it).hasNext()) {
		    System.out.println();
		    list1.add(4); 
		}

	}
}


