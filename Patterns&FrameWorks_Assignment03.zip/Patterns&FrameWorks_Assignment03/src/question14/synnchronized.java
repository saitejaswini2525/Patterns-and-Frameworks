package question14;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class synnchronized {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		
		        
		        
		        List<String> synchronizedList = Collections.synchronizedList(new ArrayList<>());
		        synchronizedList.add("one");
		        synchronizedList.add("two");
		        synchronizedList.add("three");
		        System.out.println("Synchronized list: " + synchronizedList);
		        
		        
		        List<String> arrayList = new ArrayList<>();
		        synchronized (arrayList) {
		            arrayList.add("one");
		            arrayList.add("two");
		            arrayList.add("three");
		        }
		        System.out.println("ArrayList: " + arrayList);
		    }
		}


