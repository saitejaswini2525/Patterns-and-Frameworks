package question26;

public class single {

	
		
			   private static single instance;
			   
			   private single() {
			      // Private constructor to prevent instantiation from outside
			   }
			   
			   public static single getInstance() {
			      if (instance == null) {
			         instance = new single();
			      }
			      return instance;
			   }
			

	
}
