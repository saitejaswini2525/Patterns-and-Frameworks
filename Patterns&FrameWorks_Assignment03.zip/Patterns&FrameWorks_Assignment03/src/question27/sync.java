package question27;

public class sync {
			   private static volatile sync instance;
			   
			   private sync() {


			   }
			   
			   public static sync getInstance() {
			      if (instance == null) {
			         synchronized (sync.class) {
			            if (instance == null) {
			               instance = new sync();
			            }
			         }
			      }
			      return instance;
			   }
			

	}


