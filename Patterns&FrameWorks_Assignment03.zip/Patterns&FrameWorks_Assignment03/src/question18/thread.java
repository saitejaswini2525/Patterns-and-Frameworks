package question18;

public class thread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread thread = new Thread(() -> {
		    System.out.println("Thread is running...");
		});

		thread.start(); // start the thread for the first time

		try {
		    Thread.sleep(1000); // wait for the thread to complete its execution
		} catch (InterruptedException e) {
		    e.printStackTrace();
		}

		thread.start(); // try to start the thread again

	}

}
