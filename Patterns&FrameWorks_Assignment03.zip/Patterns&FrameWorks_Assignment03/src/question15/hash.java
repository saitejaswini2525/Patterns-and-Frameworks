package question15;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class hash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		
		        
		        
		        Map<String, String> hashMap = new HashMap<>();
		        hashMap.put("one", "1");
		        hashMap.put("two", "2");
		        hashMap.put("three", "3");
		        System.out.println("HashMap: " + hashMap);
		        
		        Hashtable<String, String> hashtable = new Hashtable<>();
		        hashtable.put("one", "1");
		        hashtable.put("two", "2");
		        hashtable.put("three", "3");
		        System.out.println("Hashtable: " + hashtable);
		    }
		

	

}
