package question21;

public interface serialize {
	

}
