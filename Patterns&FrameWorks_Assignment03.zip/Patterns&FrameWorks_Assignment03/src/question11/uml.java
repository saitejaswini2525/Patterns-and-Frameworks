package question11;

import java.util.List;

public class uml {

	public static void main(String[] args) {
		
		class Employee {
		    private String name;
		    private Department01 department;
			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
		    
		    
		}

		class Department {
		    private String name;

			public String getName() {
				return name;
			}

			public void setName(String name) {
				this.name = name;
			}
		    
		   
		}

		class Engine {
		    private int horsepower;

			public int getHorsepower() {
				return horsepower;
			}

			public void setHorsepower(int horsepower) {
				this.horsepower = horsepower;
			}
		    
		    
		}


	}

}
