package question11;

public class Department01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
